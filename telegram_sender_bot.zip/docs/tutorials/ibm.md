# 📕 IBM

First create an account on IBM using your email.

[**Click here**](https://cloud.ibm.com/registration?target=%2Fdocs%2Fspeech-to-text%2Fgetting-started.html) & create your account.

<figure><img src="https://telegra.ph/file/6568a77b98f4cd4b59b47.jpg" alt=""><figcaption></figcaption></figure>

Now Login to your account.

<figure><img src="https://telegra.ph/file/a8d19717a621f182ffb6d.jpg" alt=""><figcaption></figcaption></figure>

After login [**Click Here**](https://cloud.ibm.com/catalog/services/speech-to-text) it will redirect you to Speech To Text.

Click on Create.

<figure><img src="https://telegra.ph/file/055c9927f923e46c4c4e7.jpg" alt=""><figcaption></figcaption></figure>

Then click on manage.

<figure><img src="https://telegra.ph/file/58dea00e006d57b261b43.jpg" alt=""><figcaption></figcaption></figure>

There you will find your **API KEY** & **URL**

<figure><img src="https://telegra.ph/file/bc24ecd8f8b9818ced4d0.jpg" alt=""><figcaption></figcaption></figure>

\


\=======================

Now Set those Var , Values

**IBM\_WATSON\_CRED\_PASSWORD** = **API KEY** you got here.

**IBM\_WATSON\_CRED\_URL** = **URL** you got here.

\=======================

\
