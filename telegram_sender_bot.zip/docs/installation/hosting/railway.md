# 📕 Railway

## ≡ Disclaimer

{% hint style="warning" %}
Railway doesn't authorize you if have any userbot/bot related stuff. If this happens clean github & delete railway. then make new railway with the clean github.
{% endhint %}

#### To Deploy in Railway you will need 2 things

1. [<mark style="color:blue;">GitHub account</mark>](https://github.com/) ( 30 days old & clean )
2. Verified [<mark style="color:blue;">Railway account</mark>](https://railway.app/)

## ≡ How to Host?

After testing all what I find, best method will be root railway, get a vps from railway & host.

### 〣 Get VPS from Railway :  [_<mark style="color:blue;">https://github.com/Jisan09/SSH4Me</mark>_](https://github.com/Jisan09/SSH4Me) <a href="#install-packages" id="install-packages"></a>

_Now that you got your vps follow the rest as nomal vps user, try the method below._

<table data-view="cards"><thead><tr><th></th><th></th><th data-hidden data-card-cover data-type="files"></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><em><mark style="color:blue;"><strong>Self Host</strong></mark></em></td><td><em>Host your bot manually by local hosting</em></td><td><a href="../../.gitbook/assets/5089337.jpg">5089337.jpg</a></td><td><a href="self-host.md">self-host.md</a></td></tr></tbody></table>
