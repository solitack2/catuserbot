# 📚 Guide

### _Some additonal set-up guides that might be helpful with your hosting:_

<table data-view="cards"><thead><tr><th></th><th data-type="select" data-multiple></th><th data-hidden data-card-cover data-type="files"></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><em><mark style="color:blue;"><strong>Install Chromium or Google-Chrome</strong></mark></em></td><td></td><td><a href="../../.gitbook/assets/chromium_pokemon.jpg">chromium_pokemon.jpg</a></td><td><a href="chromium-or-chrome-setup.md">chromium-or-chrome-setup.md</a></td></tr></tbody></table>
