#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from typing import Dict, List

class Config:
    # Bot Configuration
    BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN")
    OWNER_ID = int(os.getenv("OWNER_ID", "123456789"))
    
    # Database
    DATABASE_NAME = "telegram_sender.db"
    
    # Sending Limits and Delays
    DEFAULT_SEND_LIMIT = 20  # Default messages per account per session
    DEFAULT_DELAY_MIN = 30   # Minimum delay between messages (seconds)
    DEFAULT_DELAY_MAX = 60   # Maximum delay between messages (seconds)
    DEFAULT_ACCOUNT_REST = 300  # Rest time for account after sending session (seconds)
    
    # Proxy Settings
    DEFAULT_PROXY_TYPE = "socks5"  # socks5, http, or none
    MAX_ACCOUNTS_PER_PROXY = 3     # Maximum accounts per proxy
    
    # Analysis Settings
    ANALYSIS_BATCH_SIZE = 50       # How many members to analyze at once
    ANALYSIS_DELAY = 2             # Delay between member extractions (seconds)
    
    # File Paths
    SESSIONS_DIR = "sessions"
    MEDIA_DIR = "media"
    LOGS_DIR = "logs"
    
    # Create directories if they don't exist
    for directory in [SESSIONS_DIR, MEDIA_DIR, LOGS_DIR]:
        os.makedirs(directory, exist_ok=True)
    
    # Persian Messages Templates
    MESSAGES = {
        'welcome': """
🌟 **به ربات پیشرفته ارسال پیام تلگرام خوش آمدید!**

**قابلیت‌های اصلی:**
📱 مدیریت اکانت‌ها
📊 آنالیز پیشرفته ممبرها  
📤 ارسال پیام خصوصی
🏷️ دسته‌بندی اکانت‌ها
🌐 مدیریت پروکسی
⚙️ تنظیمات پیشرفته

از منوی زیر استفاده کنید:
        """,
        
        'unauthorized': "⛔ شما مجاز به استفاده از این ربات نیستید.",
        
        'account_added': "✅ اکانت با موفقیت اضافه شد!",
        'account_exists': "⚠️ این اکانت قبلاً اضافه شده است.",
        'account_error': "❌ خطا در افزودن اکانت: {}",
        
        'analysis_started': "🔍 تحلیل ممبرها شروع شد...",
        'analysis_completed': "✅ تحلیل کامل شد! {} ممبر یافت شد.",
        'analysis_stopped': "⏹️ تحلیل متوقف شد.",
        
        'sending_started': "📤 ارسال پیام شروع شد...",
        'sending_completed': "✅ ارسال کامل شد!",
        'sending_stopped': "⏹️ ارسال متوقف شد.",
        
        'settings_updated': "✅ تنظیمات به‌روزرسانی شد!",
        'category_created': "✅ دسته‌بندی جدید ایجاد شد!",
        'proxy_added': "✅ پروکسی جدید اضافه شد!"
    }
    
    # Default Settings
    DEFAULT_SETTINGS = {
        'send_limit': DEFAULT_SEND_LIMIT,
        'delay_min': DEFAULT_DELAY_MIN,
        'delay_max': DEFAULT_DELAY_MAX,
        'account_rest': DEFAULT_ACCOUNT_REST,
        'proxy_enabled': False,
        'auto_rest': True,
        'flood_wait_enabled': True
    }
    
    # Account Status Messages
    ACCOUNT_STATUS = {
        'active': "✅ فعال",
        'inactive': "❌ غیرفعال", 
        'banned': "🚫 محدود شده",
        'flood': "⏰ انتظار سیل",
        'error': "⚠️ خطا"
    }