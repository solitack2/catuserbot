import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Bot Configuration
    BOT_TOKEN = os.getenv('BOT_TOKEN', '')
    OWNER_ID = int(os.getenv('OWNER_ID', 0))
    
    # Telegram API Configuration
    API_ID = int(os.getenv('API_ID', 0))
    API_HASH = os.getenv('API_HASH', '')
    
    # Database Configuration
    DATABASE_NAME = 'telegram_sender.db'
    
    # Sending Configuration
    MAX_MESSAGES_PER_MINUTE = 20
    DELAY_BETWEEN_MESSAGES = 3  # seconds
    MAX_RETRY_ATTEMPTS = 3
    
    # Session Configuration
    SESSION_FOLDER = 'sessions'
    
    # Logging Configuration
    LOG_LEVEL = 'INFO'
    LOG_FILE = 'bot.log'
    
    # Features Configuration
    ENABLE_ANALYTICS = True
    ENABLE_SCHEDULER = True
    ENABLE_FLOOD_CONTROL = True
    
    # Message Templates
    DEFAULT_TEMPLATES = {
        'welcome': '🌟 سلام! به ربات ارسال پیام خصوصی خوش آمدید',
        'account_added': '✅ اکانت با موفقیت اضافه شد',
        'message_sent': '📤 پیام ارسال شد',
        'error': '❌ خطا در عملیات',
        'unauthorized': '🚫 شما مجاز به استفاده از این ربات نیستید'
    }